package com.salesianostriana.e07_modelosmanytomany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E07ModelosManyToManyApplication {

	public static void main(String[] args) {
		SpringApplication.run(E07ModelosManyToManyApplication.class, args);
	}

}
