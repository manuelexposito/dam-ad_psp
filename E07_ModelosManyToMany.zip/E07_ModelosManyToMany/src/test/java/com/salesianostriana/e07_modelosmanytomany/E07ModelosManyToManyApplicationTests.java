package com.salesianostriana.e07_modelosmanytomany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E07ModelosManyToManyApplicationTests {

	@Test
	void contextLoads() {
	}

}
