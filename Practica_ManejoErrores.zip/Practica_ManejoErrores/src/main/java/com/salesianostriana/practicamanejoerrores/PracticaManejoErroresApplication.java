package com.salesianostriana.practicamanejoerrores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticaManejoErroresApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticaManejoErroresApplication.class, args);
	}

}
