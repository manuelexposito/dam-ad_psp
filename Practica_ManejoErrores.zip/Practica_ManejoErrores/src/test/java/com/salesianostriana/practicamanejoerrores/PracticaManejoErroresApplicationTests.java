package com.salesianostriana.practicamanejoerrores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticaManejoErroresApplicationTests {

	@Test
	void contextLoads() {
	}

}
