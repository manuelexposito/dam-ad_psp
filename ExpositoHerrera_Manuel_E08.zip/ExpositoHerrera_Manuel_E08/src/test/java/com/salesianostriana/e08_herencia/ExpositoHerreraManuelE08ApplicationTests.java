package com.salesianostriana.e08_herencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpositoHerreraManuelE08ApplicationTests {

	@Test
	void contextLoads() {
	}

}
